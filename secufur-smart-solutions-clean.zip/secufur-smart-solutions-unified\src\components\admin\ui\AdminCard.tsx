import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

export function AdminCard({ children, className = '' }: CardProps) {
  return (
    <div className={`bg-white rounded-lg border border-gray-200 p-6 shadow-sm ${className}`}>
      {children}
    </div>
  );
}
